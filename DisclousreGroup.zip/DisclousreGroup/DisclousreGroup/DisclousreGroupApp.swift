//
//  DisclousreGroupApp.swift
//  DisclousreGroup
//
//  Created by Ufuk Köşker on 13.07.2020.
//

import SwiftUI

@main
struct DisclousreGroupApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
